All task Validators are inherited from `BaseValidator` class that contains the model validation routine boilerplate. You
can override any function of these Trainers to suit your needs.

---

### BaseValidator API Reference

:::ultralytics.yolo.engine.validator.BaseValidator